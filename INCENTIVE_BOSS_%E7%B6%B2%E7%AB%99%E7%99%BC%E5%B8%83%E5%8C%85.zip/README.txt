INCENTIVE BOSS 手機網站

發布到 GitHub Pages：
1. 登入 github.com，建立新的 Public repository，例如 incentive-boss。
2. 點 Add file > Upload files，上傳 index.html，按 Commit changes。
3. 到 Settings > Pages，Source 選 Deploy from a branch，Branch 選 main、/(root)，Save。
4. 等待部署完成後，Pages 頁面會顯示實際網址。

注意：網站本身公開可存取，沒有登入密碼。每台手機的資料各自保存在該瀏覽器 localStorage，清除網站資料會遺失。請定期匯出 CSV 備份。
